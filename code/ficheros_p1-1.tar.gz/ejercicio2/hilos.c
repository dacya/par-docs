#include <stdlib.h>
#include <stdio.h>

void *thread_usuario(void *arg)
{

}

int main(int argc, char* argv[])
{

	return 0;
}
